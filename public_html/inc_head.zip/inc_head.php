<?php 
//	if ($_SERVER["SERVER_PORT"] != 443) {
  // $url = 'https://'.$_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
?><!--
<meta http-equiv="refresh" content="0;URL='<?php echo $url;?>'" />
<?php // exit();}
?>
-->
<?php $phpext = ".php";?>
<link rel="stylesheet" type="text/css" href="chrometheme/chromestyle.css" />
<script type="text/javascript" src="chromejs/chrome.js"></script>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="USSTOKYO.com, Japan Auctions, Japanese Cars in Pakistan, Japanese Cars in South Africa" />
<meta name="description" content="www.USSTokyo.com - The Best Car Dealer in Japan" />
<meta name="author" content="www.aukinternational.co.uk" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<!-- Favicon -->
<link rel="shortcut icon" href="images/favicon.ico" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css" />
<!-- mega menu -->
<link rel="stylesheet" type="text/css" href="css/mega-menu/mega_menu.css" />
<!-- font awesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl-carousel/owl.carousel.css" />
<!-- revolution -->
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css" />
<!-- main style -->
<link rel="stylesheet" type="text/css" href="css/style.css" />
<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<meta name="google-site-verification" content="G1jboJzlcD9z2qTrbV3DAA5WEWyFzVtXY8u-MC5r6BI" />
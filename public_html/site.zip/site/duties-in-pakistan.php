<!DOCTYPE HTML>
<html class="no-js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>USSTokyo.com - The Best Car Dealer in Japan</title>
<meta name="keywords" content="USSTOKYO.com, Japan Auctions, Japanese Cars in Pakistan, Japanese Cars in South Africa" />
<?php include('inc_head.php');?>
</head>
<body class="home header-v4">
<!--[if lt IE 7]>
	<p class="chromeframe">You are using an outdated browser. <a href="http://browsehappy.com/">Upgrade your browser today</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to better experience this site.</p>
<![endif]-->
<div class="body"><?php include('inc_header.php');?></div>
    <!-- Start Page header -->
    <div class="page-header parallax" style="background-image:url(images/header_dealer.jpg);">
    	<div class="container">
        	<h1 class="page-title">Customs and Excese Duties in Pakistan</h1>
       	</div>
    </div>
    <!-- Utiity Bar -->
    <div class="utility-bar">
    	<div class="container">
        	<div class="row">
            	<div class="col-md-8 col-sm-6 col-xs-8">
                    <ol class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Customs and Excese Duties in Pakistan</li>
                    </ol>
            	</div>
                <div class="col-md-4 col-sm-6 col-xs-4">
                </div>
            </div>
      	</div>
    </div>
  	<div class="main" role="main">
    	<div id="content" class="content full">
      		<div class="container">
			<div class="listing-header margin-40 text-align-center">
                	<h2>Customs and Excese Duties in Pakistan ~ USSTOKYO.COM</h2>
                </div>
            	<div class="row">
                	<div class="col-md-12 text-align-center">
                        <img src="images/Duties-in-Pakistan-Exise.png">
						<!--<p class="lead">AutoStars is the world's leading portal for<br>easy and quick <span class="accent-color">car buying and selling</span></p>-->
                    </div>
                </div>
      	</div>
 	</div>
    <!-- End Body Content -->
    <!-- Start site footer -->
<?php include('inc_footer.php');?>	
</body>
</html>
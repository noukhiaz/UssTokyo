<div class="chromestyle" id="chromemenu">
<ul>
	<li><a href="#" rel="dropmenu1">Freight</a></li>
	<li><a href="duties-in-pakistan<?php echo $phpext;?>">Customs & Excise Duties</a></li> 
	<li><a href="packages-in-pakistan<?php echo $phpext;?>">Promotions</a></li>   
</ul>
</div>

<!--1st drop down menu -->                                                   
<div id="dropmenu1" class="dropmenudiv">
<a href="cost-per-car-in-pakistan-from-japan<?php echo $phpext;?>">660cc cars</a>
<a href="cost-660cc-family-vans-in-pakistan-from-japan<?php echo $phpext;?>">660cc Vans & Pickups</a>
<a href="cost-660cc-Sports-and-Turbo-Cars-in-pakistan-from-japan<?php echo $phpext;?>">660cc Sports & Turbo Cars</a>
<a href="cost-660cc-SUVs-in-pakistan-from-japan<?php echo $phpext;?>">660cc SUVs</a>
<a href="cost-1000cc-Cars-in-pakistan-from-japan<?php echo $phpext;?>">1000cc Cars</a>
</div>
<script type="text/javascript">cssdropdown.startchrome("chromemenu")</script>
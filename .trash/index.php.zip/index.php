<?php session_start();

		include('panel/config.php');

?>

<!DOCTYPE html>

<html lang="en">

<head>

<title>www.USSTokyo.com - The Best Car Dealer in Japan</title>

<?php include('inc_head.php');?>

</head>



<body>



<!--=================================

  loading -->

  
<!--
 <div id="loading">

  <div id="loading-center">

      <img src="images/loader2.gif" alt="">

 </div>

</div>-->



<!--=================================

  loading -->





<!--=================================

 header -->



<header id="header" class="defualt">

<?php include('inc_menu_top.php');?>

<!--================================= mega menu -->

<div class="menu">  

	<?php include('inc_menu.php');?>

 </div>

</header>



<!--================================= header -->





<!--=================================

 rev slider -->



<div id="rev_slider_4_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="car-dealer-04" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">

<!-- START REVOLUTION SLIDER 5.3.0.2 fullwidth mode -->

  <div id="rev_slider_4_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.3.0.2">

<ul>  <!-- SLIDE  -->

    <li data-index="rs-5" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="revolution/assets/100x50_75b06-bg-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

    <!-- MAIN IMAGE -->

        <img src="revolution/assets/75b06-bg-1.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>

    <!-- LAYERS -->



    <!-- LAYER NR. 1 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 

       id="slide-5-layer-4" 

       data-x="10" 

       data-y="361" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="text" 

      data-responsive_offset="on" 



            data-frames='[{"delay":1450,"speed":1650,"frame":"0","from":"x:right;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 5; white-space: nowrap; font-size: 120px; line-height: 120px; font-weight: 900; color: rgba(255, 255, 255, 1.00);font-family:Roboto;text-transform:uppercase;"> </div>



    <!-- LAYER NR. 2 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 

       id="slide-5-layer-2" 

       data-x="14" 

       data-y="299" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="text" 

      data-responsive_offset="on" 



            data-frames='[{"delay":1410,"speed":1740,"frame":"0","from":"y:top;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['right','right','right','right']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 6; white-space: nowrap; font-size: 50px; line-height: 50px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family:Roboto;"></div>



    <!-- LAYER NR. 3 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 

       id="slide-5-layer-7" 

       data-x="right" data-hoffset="50" 

       data-y="bottom" data-voffset="350" 

            data-width="['none','none','none','none']"

      data-height="['none','none','none','none']"

 

            data-type="image" 

      data-responsive_offset="on" 



            data-frames='[{"delay":3170,"speed":900,"frame":"0","from":"y:50px;opacity:0;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 7; white-space: nowrap; font-size: 50px; line-height: 50px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family:Roboto;">

			

			<!--<img src="revolution/assets/2bd73-logo.jpg" alt="" data-ww="auto" data-hh="auto" data-no-retina> -->

			</div>



    <!-- LAYER NR. 4 -->

    <div class="tp-caption   tp-resizeme" 

       id="slide-5-layer-3" 

       data-x="center" data-hoffset="16" 

       data-y="bottom" data-voffset="118" 

            data-width="['none','none','none','none']"

      data-height="['none','none','none','none']"

 

            data-type="image" 

      data-responsive_offset="on" 



            data-frames='[{"delay":360,"speed":1600,"frame":"0","from":"x:right;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"x:left;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 8;"><img src="LC_.png" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>



    <!-- LAYER NR. 5 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 

       id="slide-5-layer-5" 

       data-x="right" data-hoffset="14" 

       data-y="bottom" data-voffset="50" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="text" 

      data-responsive_offset="on" 



            data-frames='[{"delay":1450,"speed":1650,"frame":"0","from":"y:bottom;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 9; white-space: nowrap; font-size: 120px; line-height: 120px; font-weight: 900; color: rgba(255, 255, 255, 1.00);font-family:Roboto;text-transform:uppercase;">Track </div>



    <!-- LAYER NR. 6 -->

    <div class="tp-caption button red rs-parallaxlevel-1" 

       id="slide-5-layer-8" 

       data-x="14" 

       data-y="bottom" data-voffset="39" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="button" 

      data-responsive_offset="on" 

       

            data-frames='[{"delay":3990,"speed":600,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","force":true,"to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bg:rgba(219, 45, 46, 1.00);bc:rgba(0, 0, 0, 1.00);bs:solid;bw:0 0 0 0;"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[10,10,10,10]"

            data-paddingright="[30,30,30,30]"

            data-paddingbottom="[10,10,10,10]"

            data-paddingleft="[30,30,30,30]"



            style="z-index: 10; white-space: nowrap; font-size: 14px; line-height: 16px; font-weight: 400; font-family:Open Sans;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">Explore now </div>

  </li>

  <!-- SLIDE  -->

    <li data-index="rs-6" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="revolution/assets/100x50_1b65c-bg-2.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

    <!-- MAIN IMAGE -->

        <img src="revolution/assets/1b65c-bg-2.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>

    <!-- LAYERS -->



    <!-- LAYER NR. 7 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 

       id="slide-6-layer-4" 

       data-x="12" 

       data-y="301" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="text" 

      data-responsive_offset="on" 



            data-frames='[{"delay":1450,"speed":1650,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 5; white-space: nowrap; font-size: 100px; line-height: 150px; font-weight: 900; color: rgba(255, 255, 255, 1.00);font-family:Roboto;text-transform:uppercase;">drive me </div>



    <!-- LAYER NR. 8 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 

       id="slide-6-layer-2" 

       data-x="14" 

       data-y="250" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="text" 

      data-responsive_offset="on" 



            data-frames='[{"delay":1410,"speed":1740,"frame":"0","from":"y:top;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 6; white-space: nowrap; font-size: 50px; line-height: 50px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family:Roboto;">Ferrari  </div>



    <!-- LAYER NR. 9 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 

       id="slide-6-layer-7" 

       data-x="right" data-hoffset="50" 

       data-y="bottom" data-voffset="350" 

            data-width="['none','none','none','none']"

      data-height="['none','none','none','none']"

 

            data-type="image" 

      data-responsive_offset="on" 



            data-frames='[{"delay":3170,"speed":900,"frame":"0","from":"y:50px;opacity:0;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 7;"><img src="revolution/assets/dfced-logo2.jpg" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>



    <!-- LAYER NR. 10 -->

    <div class="tp-caption   tp-resizeme" 

       id="slide-6-layer-3" 

       data-x="center" data-hoffset="-3" 

       data-y="center" data-voffset="109" 

            data-width="['none','none','none','none']"

      data-height="['none','none','none','none']"

 

            data-type="image" 

      data-responsive_offset="on" 



            data-frames='[{"delay":360,"speed":1600,"frame":"0","from":"x:right;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"x:left;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 8;"><img src="revolution/assets/6a297-car-02.png" alt="" data-ww="auto" data-hh="auto" data-no-retina> </div>



    <!-- LAYER NR. 11 -->

    <div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 

       id="slide-6-layer-5" 

       data-x="right" data-hoffset="10" 

       data-y="bottom" data-voffset="109" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="text" 

      data-responsive_offset="on" 



            data-frames='[{"delay":1450,"speed":1650,"frame":"0","from":"y:bottom;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[0,0,0,0]"

            data-paddingright="[0,0,0,0]"

            data-paddingbottom="[0,0,0,0]"

            data-paddingleft="[0,0,0,0]"



            style="z-index: 9; white-space: nowrap; font-size: 100px; line-height: 100px; font-weight: 900; color: rgba(255, 255, 255, 1.00);font-family:Roboto;text-transform:uppercase;">but fast! </div>



    <!-- LAYER NR. 12 -->

    <div class="tp-caption button red rs-parallaxlevel-1" 

       id="slide-6-layer-8" 

       data-x="10" 

       data-y="bottom" data-voffset="39" 

            data-width="['auto']"

      data-height="['auto']"

 

            data-type="button" 

      data-responsive_offset="on" 

      

            data-frames='[{"delay":3990,"speed":600,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","force":true,"to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(255, 255, 255, 1.00);bg:rgba(219, 45, 46, 1.00);bc:rgba(0, 0, 0, 1.00);bs:solid;bw:0 0 0 0;"}]'

            data-textAlign="['left','left','left','left']"

            data-paddingtop="[10,10,10,10]"

            data-paddingright="[30,30,30,30]"

            data-paddingbottom="[10,10,10,10]"

            data-paddingleft="[30,30,30,30]"



            style="z-index: 10; white-space: nowrap; font-size: 14px; line-height: 16px; font-weight: 400; font-family:Open Sans; outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">Discover More </div>

  </li>

</ul>

<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div> </div>

</div>



<!--=================================

  rev slider -->

 



 <!--=================================

 welcome -->



<section class="welcome-2 bg-4">

  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12">

         <div class="custom-block-2">
<center>
           <h4>Welcome to the USSTOKYO.com </h4>
<p>We are here as a bridge between the customers from all over the world and the Japanese Car Auctions.
We are here to make it as easy for you to buy your dream car from Japan as you buy something from a store near you.
<br />
We will take care of all steps, like buying from auctions, shipping and delivering your dream car to your doorstep.
</p>

</center>

           <div class="ceo">

<!--
             <img class="img-responsive" src="images/signature.png" alt="">

             <strong class="text-red">CEO</strong>

             <p>Kevin walsh

			 <br /><br /><br />
</p>
		-->	 

           </div>

         </div>

      </div>
<!--
      <div class="col-lg-5 col-md-5" style="border: 1px solid #e3e3e3;">

<img src="investors.PNG" style="width: 100%;">
-->

<!--
<div class="search-block">

			<div class="row no-gutter">

			   <div class="col-lg-12 col-md-12 text-center">

				 <h3 class="title text-white"> <i class="fa fa-search"></i> SEARCH HERE </h3>

			   </div> 

			</div> 

		</div>



<br />



		
<form method="get" class="form-horizontal" action="auction.php">


		<div class="col-lg-6 col-md-6 col-sm-6">

            <span>Select make</span>

              <div class="selected-box">

                <select class="selectpicker" name="mark_name" >

                <option value="">Make </option>

                <option value="TOYOTA">TOYOTA</option>

                                    
                                    <option value="NISSAN">NISSAN</option>

                                    
                                    <option value="HONDA">HONDA</option>

                                    
                                    <option value="MAZDA">MAZDA</option>

                                    
                                    <option value="SUZUKI">SUZUKI</option>

                                    
                                    <option value="DAIHATSU">DAIHATSU</option>

                                    
                                    <option value="SUBARU">SUBARU</option>

                                    
                                    <option value="ISUZU">ISUZU</option>

                                    
                                    <option value="MERCEDES BENZ">MERCEDES BENZ</option>

                                    
                                    <option value="BMW">BMW</option>

                                    
                                    <option value="AUDI">AUDI</option>

                                    
                                    <option value="OPEL">OPEL</option>

                                    
                                    <option value="VOLVO">VOLVO</option>

                                    
                                    <option value="ROVER">ROVER</option>

                                    
                                    <option value="GM">GM</option>

                                    
                                    <option value="CHRYSLER">CHRYSLER</option>

                                    
                                    <option value="FORD">FORD</option>

                                    
                                    <option value="ALFAROMEO">ALFAROMEO</option>

                                    
                                    <option value="FIAT">FIAT</option>

                                    
                                    <option value="CITROEN">CITROEN</option>

                                    
                                    <option value="PEUGEOT">PEUGEOT</option>

                                    
                                    <option value="RENAULT">RENAULT</option>

                                    
                                    <option value="OTHERS">OTHERS</option>


               </select>

              </div>

            </div>

             
              <input type="hidden" name="auction" value="">
              <input type="hidden" name="date" value="">
              <input type="hidden" name="year_to" value="">
              <input type="hidden" name="mileage_to" value="">
              <input type="hidden" name="price_to" value="">
              <input type="hidden" name="displace_from" value="">
              <input type="hidden" name="displace_to" value="">

            <div class="col-lg-6 col-md-6 col-sm-6">



              

            <span>Select model</span>

              <div class="selected-box" name="model">

               <select class="selectpicker"  name="model" >

                
                <option value="">Model</option>

                <option>3-Series</option>

                <option>Carrera</option>

                <option>GT-R</option>

                <option>Cayenne</option>

                <option>Mazda6</option>

                <option>Macan</option>

               </select>

             </div>

            </div>


			<div class="col-lg-6 col-md-6 col-sm-6">

            <span>Select year</span>

             <div class="selected-box">

               <select class="selectpicker" name="year_from">

                <option value="">Year</option>

                


                                    <option>2017</option>
                                    <option>2016</option>
                                    <option>2015</option>
                                    <option>2014</option>
                                    <option>2013</option>
                                    <option>2012</option>
                                    <option>2011</option>
                                    <option>2010</option>
                                    <option>2009</option>
                                    <option>2008</option>
                                    <option>2007</option>
                                    <option>2006</option>
                                    <option>2005</option>
                                    <option>2004</option>
                                    <option>2003</option><option>2002</option><option>2001</option><option>2000</option><option>1999</option><option>1998</option><option>1997</option><option>1996</option><option>1995</option><option>1994</option><option>1993</option><option>1992</option><option>1991</option><option>1990</option>
                


               </select>

              </div>

            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">

           


              <span>Select Starting Price</span>

             <div class="selected-box">

               <select class="selectpicker" name="price_start" >


                                    <option value="">Price</option>

                                    <option value="100000">100,000</option>

                                    <option value="300000">300,000</option>

                                    <option value="500000">500,000</option>

                                    <option value="800000">800,000</option>

                                    <option value="1000000">10,00,000</option>

                                    <option value="3000000">30,00,000</option>

                                 </select>


             </div>

            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">

            <span>Lot No.</span>

            <div class="selected-box">

            
               <input class="selectpicker" type="text" name="lot" style="    width: 192px;
    height: 39px;
    padding-top: 6px;
    padding-bottom: 6px;
    padding-left: 6px;
    padding-right: 6px; border: 1px solid #e3e3e3;">

              </div>

            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">

           <span>Mileage From</span>

             <div class="selected-box">

               <select class="selectpicker" name="mileage_from">

                <option value="">Milage</option>
                <option>1000</option>

                <option>5000</option>

                <option>10000</option>

                <option>15000</option>

                <option>20000</option>
               

               </select>

             </div>

            </div>

			<br />&nbsp

            <div class="col-lg-12 col-md-12">

             <div class="">

                <div class="price">

                 

                 
                  <input id="submit" name="submit" type="submit" value="Send" class="button">


                </div>

               </div>

              </div>

			<br />&nbsp
    </form>

		-->	

        <!--<div class="counter counter-style-1 counter-light">

           <ul class="list-style-none">

             <li>

               <div class="counter-box text-right">

                 <div class="info">

                    <b class="timer" data-to="400" data-speed="10000"></b>

                    <h6 class="text-white">Vehicles Stock</h6>

                 </div>

                 <div class="icon">

                   <i class="glyph-icon flaticon-beetle"></i>

                 </div>

               </div>

             </li>

             <li>

               <div class="counter-box text-left">

               <div class="icon">

                   <i class="glyph-icon flaticon-interface"></i>

                 </div>

                 <div class="info">

                    <b class="timer" data-to="1000" data-speed="10000"></b>

                    <h6 class="text-white">Dealer Reviews</h6>

                 </div>

               </div>

             </li>

             <li>

               <div class="counter-box text-right">

                 <div class="info">

                    <b class="timer" data-to="1500" data-speed="10000"></b>

                    <h6 class="text-white">Happy Customer</h6>

                 </div>

                 <div class="icon">

                   <i class="glyph-icon flaticon-circle"></i>

                 </div>

               </div>

             </li>

             <li>

               <div class="counter-box text-left">

               <div class="icon">

                  <i class="glyph-icon flaticon-cup"></i>

                 </div>

                 <div class="info">

                    <b class="timer" data-to="450" data-speed="10000"></b>

                    <h6 class="text-white">Awards</h6>

                 </div>

               </div>

             </li>

           </ul>

        </div>-->
<!--
      </div>
-->
	  <br />&nbsp

    </div>
<br /><br /><br /><br />
	<div class="row">

      <div class="col-lg-3 col-md-3 col-sm-6">

        <div class="content-box text-center">

          <div class="box-info">

            <i class="glyph-icon flaticon-beetle"></i>

            <h5>Auctions</h5>

            <p>We give you access to all Auction Houses in Japan, including UssTokyo , the biggest cars auction in the world.</p>

            </div>

          <a href="about.php">Read more</a>

          <div class="content-box-img" style="background-image: url('images/car/01.jpg');"></div>

          <span class="border"></span>

          </div>

      </div>

      <div class="col-lg-3 col-md-3 col-sm-6">
<!--class active-->
        <div class="content-box text-center ">

          <div class="box-info">

            <i class="glyph-icon flaticon-electrical-service"></i>

            <h5>No Hidden Costs</h5>

            <p> Buying direct from Auctions means there will be no hidden costs and you get what you <br />buy.</p>

            </div>

          <a href="about.php">Read more</a>

          <div class="content-box-img" style="background-image: url('images/car/02.jpg');"></div>

          <span class="border"></span>

          </div>

      </div>

      <div class="col-lg-3 col-md-3 col-sm-6">

        <div class="content-box text-center">

          <div class="box-info">

            <i class="glyph-icon flaticon-reparation"></i>

            <h5>Investors' Portal</h5>

            <p>Buy a car from any auction and sell it to customers anywhere in the world through our Investors’ Portal. </p>

            </div>
<a href="about.php">Read more</a>

          <div class="content-box-img" style="background-image: url('images/car/03.jpg');"></div>

          <span class="border"></span>

          </div>

      </div>

      <div class="col-lg-3 col-md-3 col-sm-6">

        <div class="content-box text-center">

          <div class="box-info">

            <i class="glyph-icon flaticon-car"></i>

            <h5>Secured Payments</h5>

            <p>All payments are totally secured with our trusted payment system.<br />
&nbsp
            </p>

            </div>

          <a href="about.php">Read more</a>

          <div class="content-box-img" style="background-image: url('images/car/04.jpg');"></div>

          <span class="border"></span>

          </div>

      </div>

    </div>
<br /><br /><br /><br /><br /><br /><br /><br />
  </div>

</section>  



<!--=================================

 welcome -->

   

 

<!--=================================

 feature-car -->



<section class="feature-car white-bg page-section-ptb">

  <div class="container">

   <div class="row">

    <div class="col-lg-12 col-md-12">

      <div class="section-title">

         <span>Check out the newest cars in our stock!</span>

         <h2>Our Stock </h2>

         <div class="separator"></div>

      </div>

    </div>

   </div>

   <div class="row">

   <div class="col-lg-12 col-md-12">

    <div class="owl-carousel-1">
<?php $sql = mysql_query("select * from cars where is_active = '1' order by id desc limit 40");
while($row = mysql_fetch_array($sql)){?>	

     <div class="item">

       <div class="car-item gray-bg text-center">

         <div class="car-image">

<?php 
$id = $row['id'];
$px_sql = mysql_query("select * from car_pix where car_id = '$id' order by is_front desc limit 1");
$sql_px = mysql_fetch_assoc($px_sql);
//if($sql_px['is_front'] == '0'){echo 'none';}else{
?>
<a href="car_detail<?php echo $phpext;?>?id=<?php echo $row['id'];?>" target="_blank">
<center>												
	<img src="uploads/<?php echo $sql_px['pic_name'];?>" class="img-responsive" style="max-height:168px" />	
</center>
</a>		   


<!--
			   <a href="car_detail.php?id=<?php echo $row['id'];?>">
               <div class="car-overlay-banner">
                <ul> 
                  <li><a href="car_detail.php?id=<?php echo $row['id'];?>"><i class="fa fa-link"></i></a></li>
                  <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                 </ul>
               </div></a>-->

         </div>

         <div class="car-list">

           <ul class="list-inline">
<?php if($row['year'] != ''){?><li style="padding-right: 0px; padding-left: 0px;"><i class="fa fa-registered" style="padding-right:0px;"></i> <?php echo $row['year'];?></li><?php }?>
                <?php if($row['trans'] != ''){?><li style="padding-right: 0px; padding-left: 0px;"><i class="fa fa-cog" style="padding-right:0px;"></i> <?php echo $row['trans'];?> </li><?php }?>
                 <?php if($row['mileage'] != ''){?><li style="padding-right: 0px; padding-left: 0px;"><i class="fa fa-dashboard" style="padding-right:0px;"></i> <?php echo number_format($row['mileage']);?> km</li><?php }?>

           </ul>

        </div>

         <div class="car-content">

         

           <?php 
$bid = $row['brands_id'];
$mid = $row['make'];
$sqlcompanies = mysql_query("select * from companies where id = '$mid'");
$mcid = mysql_fetch_array($sqlcompanies);

$sqlbrands = mysql_query("select * from brands where id = '$bid'");
$bid = mysql_fetch_array($sqlbrands);
			   ?>
               <a style="margin-bottom:0px;"  target="_blank" href="car_detail<?php echo $phpext;?>?id=<?php echo $row['id'];?>"><?php echo $mcid['name'];?> - <?php echo $row['brands_id'];?></a>

 <div class="star" style="margin-bottom:10px;">
<!--
           <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star-o orange-color"></i>

    -->    <span style="color:#c20003"><?php echo $row['grade'];?>   </span></div>
		   <!--
           <div class="separator"></div>
-->
           <div class="price">

            <!--<span class="old-price">$35,568</span>-->
                 <span class="new-price">&yen;<?php echo $row['price'];?>  </span>

           </div>



         </div>

       </div>

     </div>
<?php }?>
<!--
     <div class="item">

       <div class="car-item gray-bg text-center">

         <div class="car-image">

           <img class="img-responsive" src="images/car/02.jpg" alt="">

           <div class="car-overlay-banner">

            <ul> 

              <li><a href="#"><i class="fa fa-link"></i></a></li>

              <li><a href="#"><i class="fa fa-dashboard"></i></a></li>

             </ul>

           </div>

         </div>

         <div class="car-list">

           <ul class="list-inline">

             <li><i class="fa fa-registered"></i> 2017</li>

             <li><i class="fa fa-cog"></i> Manual </li>

             <li><i class="fa fa-dashboard"></i> 6,000 mi</li>

           </ul>

        </div>

         <div class="car-content">

          <div class="star">

           <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star-o orange-color"></i>

           </div>

           <a href="#">Lexus GS 450h</a>

           <div class="separator"></div>

           <div class="price">

             <span class="old-price">$35,568</span>

             <span class="new-price">$32,698 </span>

           </div>

         </div>

       </div>

     </div>

     <div class="item">

       <div class="car-item gray-bg text-center">

         <div class="car-image">

           <img class="img-responsive" src="images/car/03.jpg" alt="">

           <div class="car-overlay-banner">

            <ul> 

              <li><a href="#"><i class="fa fa-link"></i></a></li>

              <li><a href="#"><i class="fa fa-dashboard"></i></a></li>

             </ul>

           </div>

         </div>

         <div class="car-list">

           <ul class="list-inline">

             <li><i class="fa fa-registered"></i> 2017</li>

             <li><i class="fa fa-cog"></i> Manual </li>

             <li><i class="fa fa-dashboard"></i> 6,000 mi</li>

           </ul>

        </div>

         <div class="car-content">

          <div class="star">

           <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star-o orange-color"></i>

           </div>

           <a href="#">GTA 5 Lowriders DLC</a>

           <div class="separator"></div>

           <div class="price">

             <span class="old-price">$35,568</span>

             <span class="new-price">$32,698 </span>

           </div>

         </div>

       </div>

     </div>

     <div class="item">

       <div class="car-item gray-bg text-center">

         <div class="car-image">

           <img class="img-responsive" src="images/car/04.jpg" alt="">

           <div class="car-overlay-banner">

            <ul> 

              <li><a href="#"><i class="fa fa-link"></i></a></li>

              <li><a href="#"><i class="fa fa-dashboard"></i></a></li>

             </ul>

           </div>

         </div>

         <div class="car-list">

           <ul class="list-inline">

             <li><i class="fa fa-registered"></i> 2017</li>

             <li><i class="fa fa-cog"></i> Manual </li>

             <li><i class="fa fa-dashboard"></i> 6,000 mi</li>

           </ul>

        </div>

         <div class="car-content">

          <div class="star">

           <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star orange-color"></i>

            <i class="fa fa-star-o orange-color"></i>

           </div>

           <a href="#">Toyota avalon hybrid </a>

           <div class="separator"></div>

           <div class="price">

             <span class="old-price">$35,568</span>

             <span class="new-price">$32,698 </span>

           </div>

         </div>

       </div>

     </div>
-->
     

    </div>

   </div>

  </div>

  </div>

</section>   



<!--=================================

 feature-car -->

 



<!--



<section class="testimonial-2 bg-1 bg-overlay-black-70 page-section-ptb">

  <div class="container">

   <div class="row">

    <div class="col-lg-12 col-md-12">

      <div class="section-title">

         <span class="text-white">What Our Happy Clients say about us </span>

         <h2 class="text-white">Our Testimonial </h2>

         <div class="separator"></div>

      </div>

    </div>

   </div>

   <div class="testimonial-center">

    <div class="owl-carousel-3">

     <div class="item">

       <div class="testimonial-block">

        <div class="testimonial-content">

         <i class="fa fa-quote-left"></i>

         <p> Sports betting While most people enjoy casino gambling, lottery and bingo playing for the fun and excitement it provides, others may experience gambling as an addictive and distractive habit.</p>

       </div>

       <div class="testimonial-info">

         <div class="testimonial-avatar">

           <img class="img-responsive" src="images/team/01.jpg" alt="">

         </div>

         <div class="testimonial-name">

           <h6 class="text-white">John Doe</h6>

           <span> |Auto Dealer</span>

         </div>

        </div>

       </div>

     </div>

     <div class="item">

       <div class="testimonial-block">

        <div class="testimonial-content">

         <i class="fa fa-quote-left"></i>

         <p>First up, if you believe you can’t then of course you can’t. Second up, just imagine these things. They do not have to be in cinema screen perfect detail. You can remember what colour what.</p>

       </div>

       <div class="testimonial-info">

         <div class="testimonial-avatar">

           <img class="img-responsive" src="images/team/02.jpg" alt="">

         </div>

         <div class="testimonial-name">

           <h6 class="text-white">Alice Williams</h6>

           <span> |Car Dealer</span>

         </div>

        </div>

      </div>

     </div>

     <div class="item">

       <div class="testimonial-block">

        <div class="testimonial-content">

         <i class="fa fa-quote-left"></i>

         <p>Step out on to the path to your left. Where there is no change. Briefly imagine that you are not going to live and discover your unfulfilled dreams. Instead, you continue doing what you.</p>

       </div>

       <div class="testimonial-info">

         <div class="testimonial-avatar">

           <img class="img-responsive" src="images/team/03.jpg" alt="">

         </div>

         <div class="testimonial-name">

           <h6 class="text-white">Kadir Iran</h6>

           <span> |Customer </span>

         </div>

       </div>

      </div>

     </div>

     <div class="item">

       <div class="testimonial-block">

        <div class="testimonial-content">

         <i class="fa fa-quote-left"></i>

         <p> Sports betting While most people enjoy casino gambling, lottery and bingo playing for the fun and excitement it provides, others may experience gambling as an addictive and distractive habit.</p>

       </div>

       <div class="testimonial-info">

         <div class="testimonial-avatar">

           <img class="img-responsive" src="images/team/04.jpg" alt="">

         </div>

         <div class="testimonial-name">

           <h6 class="text-white">Sara Lisbon</h6>

           <span> |Car Dealer</span>

         </div>

        </div>

      </div>

     </div>

    </div>

   </div>

  </div>

</section>   
-->


<!--=================================

 testimonial -->





 





 <!--=================================

our-clients -->

<!--

<section class="our-clients gray-bg page-section-ptb">

  <div class="container">

   <div class="row">

     <div class="col-lg-12 col-md-12">

       <div class="owl-carousel-6">

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/01.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/02.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/03.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/04.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/05.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/06.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/07.png" alt="">

          </div>

          <div class="item">

            <img class="img-responsive center-block" src="images/clients/08.png" alt="">

          </div>

       </div>

     </div>

    </div>

  </div>

</section> 

-->

<!--=================================

our-clients -->





<!--=================================

 footer -->



<footer class="footer footer-black bg-3 bg-overlay-black-90">

<?php include('inc_footer.php');?>

</footer>



 <!--=================================

 footer -->



 <!--=================================

 back to top -->



<div class="car-top">

  <span><img src="images/car.png" alt=""></span>

</div>



 <!--=================================

 back to top -->

 



<!--=================================

 jquery -->



<!-- jquery  -->

<script type="text/javascript" src="js/jquery.min.js"></script>

 

<!-- bootstrap -->

<script type="text/javascript" src="js/bootstrap.min.js"></script>



<!-- mega-menu -->

<script type="text/javascript" src="js/mega-menu/mega_menu.js"></script>



<!-- appear -->

<script type="text/javascript" src="js/jquery.appear.js"></script>



<!-- counter -->

<script type="text/javascript" src="js/counter/jquery.countTo.js"></script>



<!-- owl-carousel -->

<script type="text/javascript" src="js/owl-carousel/owl.carousel.min.js"></script>



<!-- select -->

<script type="text/javascript" src="js/select/jquery-select.js"></script>



<!-- revolution -->

<script type="text/javascript" src="revolution/js/jquery.themepunch.tools.min.js"></script>

<script type="text/javascript" src="revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>

<script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>



<!-- custom -->

<script type="text/javascript" src="js/custom.js"></script>



<script type="text/javascript">

  (function($){

  "use strict";



    var tpj=jQuery;

      var revapi4;

      tpj(document).ready(function() {

        if(tpj("#rev_slider_4_1").revolution == undefined){

          revslider_showDoubleJqueryError("#rev_slider_4_1");

        }else{

          revapi4 = tpj("#rev_slider_4_1").show().revolution({

            sliderType:"standard",

            sliderLayout:"fullwidth",

            dottedOverlay:"none",

            delay:9000,

            navigation: {

              keyboardNavigation:"off",

              keyboard_direction: "horizontal",

              mouseScrollNavigation:"off",

             mouseScrollReverse:"default",

              onHoverStop:"off",

              bullets: {

                enable:true,

                hide_onmobile:false,

                style:"uranus",

                hide_onleave:false,

                direction:"horizontal",

                h_align:"right",

                v_align:"bottom",

                h_offset:40,

                v_offset:40,

                                space:8,

                tmp:'<span class="tp-bullet-inner"></span>'

              }

            },

            visibilityLevels:[1240,1024,778,480],

            gridwidth:1170,

            gridheight:900,

            lazyType:"none",

            parallax: {

              type:"mouse",

              origo:"enterpoint",

              speed:400,

              levels:[2,5,7,10,12,35,40,42,45,46,47,48,49,50,51,55],

              type:"mouse",

            },

            shadow:0,

            spinner:"spinner3",

            stopLoop:"off",

            stopAfterLoops:-1,

            stopAtSlide:-1,

            shuffle:"off",

            autoHeight:"off",

            disableProgressBar:"on",

            hideThumbsOnMobile:"off",

            hideSliderAtLimit:0,

            hideCaptionAtLimit:0,

            hideAllCaptionAtLilmit:0,

            debugMode:false,

            fallbacks: {

              simplifyAll:"off",

              nextSlideOnWindowFocus:"off",

              disableFocusListener:false,

            }

          });

        }

      });  

 })(jQuery);



</script>

  

</body>

</html>

